package com.example.ejercicio2b;

public class recyclerAdapter {
}
